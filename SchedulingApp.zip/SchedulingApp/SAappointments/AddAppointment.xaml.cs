﻿using Renci.SshNet.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SchedulingApp.SAappointments
{
    /// <summary>
    /// Interaction logic for AppointmentAdd.xaml
    /// </summary>
    public partial class AddAppointment : Window
    {

        private List<CustomerData> listCd;
        private List<UserData> listUd;
        private List<AppointmentData> listAd = new List<AppointmentData>();
        List<string> listApp = new List<string>();
        private int appointId = 0;
        private int userId;
        private DateTime start;
        private DateTime end;
    
        public AddAppointment(int apptId, int useId)
        {
            InitializeComponent();

            if (useId != 0)
            {
                userId = useId;
            }

            //List<CustomerData> listCd = new List<CustomerData>();
            List<string> listLoc = new List<string>();

            DbData data = new DbData();

            listCd = data.GetCustomerNames();
            listLoc = data.GetLocations();
            listUd = data.GetUserName();
            listAd = data.GetUserAppointmentsByUserId(userId);
            listApp = data.GetAppointmentType();
                        
            LoadComboboxCustomerNames(listCd);
            LoadComboboxLocations(listLoc);
            LoadComboboxUsers(listUd);
            LoadAppType();
            LoadTimeInterval();

            if (apptId != 0)
            {
                Add_Edit_Appointment.Content = "Edit Existing Appointment";
                appointId = apptId;
                AppointmentData ad = new AppointmentData();
                ad = data.getAppointmentByAppointmentId(appointId);
                LoadEditAppointment(ad);

            }
        }

        //loads appointment record for editing
        private void LoadEditAppointment(AppointmentData ad)
        {
            ComboAddCName.Text = ad.customerName;
            TxtAddCPhoneNumber.Text = ad.contact;
            ComboAppType.Text = ad.type;
            var uName = listUd.Find(u => u.userId == ad.userId);
            ComboConsultant.Text = uName.userName;
            StartDate.SelectedDate = ad.start.Date;
            comboStartTime.SelectedItem = ConvertDateTime(ad.start);
            EndDate.SelectedDate = ad.end.Date;
            comboEndTime.SelectedItem = ConvertDateTime(ad.end);
            ComboLocation.Text = ad.location;

        }

        //generates customer names from the database into a dropdown menu on the form
        private void LoadComboboxCustomerNames(List<CustomerData> listCd)
        {
            foreach (var c in listCd)
            {
                ComboAddCName.Items.Add(c.customerName);
            }
        }

        //generates locations from the database into a dropdown menu on the form
        private void LoadComboboxLocations(List<string> listLoc)
        {
            foreach (var l in listLoc)
            {
                ComboLocation.Items.Add(l);
            }
        }

        //generates appointment types from the database into a dropdown menu on the form
        private void LoadAppType()
        {
            foreach (var a in listApp)
            {
                ComboAppType.Items.Add(a);
            }
        }

        //generates user names from the database into a dropdown menu on the form
        private void LoadComboboxUsers(List<UserData> listUd)
        {
            foreach (var u in listUd)
            {
                ComboConsultant.Items.Add(u.userName);
            }
        }

        private void LoadTimeInterval()
        {
            var startTime = DateTime.Parse("12:00:00 AM");
            for (int x = 0; x < 96; x++)
            {
                comboStartTime.Items.Add(startTime.ToShortTimeString());
                comboEndTime.Items.Add(startTime.ToShortTimeString());
                startTime = startTime.AddMinutes(15);
            }
        }

        //enumerates the customer's phone number from the client record in the database when the customer name is selected from the drop down
        private void ComboAddCName_LostFocus(object sender, RoutedEventArgs e)
        {
            var customer = ComboAddCName.Text;
            try
            {
                if (ComboAddCName.SelectedItem != null)
                {
                    //using lambda expression to avoid looping through entire database for customer name
                    var name = listCd.Find(c => c.customerName == customer);
                    DbData db = new DbData();
                    var phone = db.GetCustomerNumber(name.customerId);
                    TxtAddCPhoneNumber.Text = phone;
                }
            }
            catch (NullReferenceException nrex)
            {
                MessageBox.Show("Customer name is required", "Error", MessageBoxButton.OK);
                throw nrex;
            }
        }

        //form validation
        private bool validateForm()
        {
            int number;
            bool valid = true;

            try
            {
                if (String.IsNullOrEmpty(ComboAddCName.Text))
                    valid = false;
                if (String.IsNullOrEmpty(TxtAddCPhoneNumber.Text) && int.TryParse(TxtAddCPhoneNumber.Text, out number))
                    valid = false;
                if (String.IsNullOrEmpty(ComboAppType.Text))
                    valid = false;
                if (String.IsNullOrEmpty(ComboConsultant.Text))
                    valid = false;
                if ((StartDate.SelectedDate != null && comboStartTime.Text != null || (EndDate.SelectedDate != null && comboEndTime.Text != null)))
                {
                    if (StartDate.SelectedDate > EndDate.SelectedDate && int.TryParse(StartDate.Text, out number))
                        valid = false;
                    start = GetDateTime(Convert.ToDateTime(StartDate.SelectedDate), comboStartTime.Text);
                    end = GetDateTime(Convert.ToDateTime(EndDate.SelectedDate), comboEndTime.Text);
                    if (start > end)
                    {
                        valid = false;
                        MessageBox.Show("The end date or time selected is earlier than the start time. Please adjust the range.", "Error", MessageBoxButton.OK);
                    }
                }
                if (String.IsNullOrEmpty(ComboLocation.Text))
                    valid = false;
                               
                if (valid == true)
                {
                    var v = CheckDateTimeRange(start, end);
                    if (v == false)
                    {
                        valid = false;
                        MessageBox.Show("The scheduled time is outside of business hours. Please adjust the start and end times.", "Error", MessageBoxButton.OK);
                    }
                    else
                    {


                        foreach (var app in listAd)
                        {
                            if ((start >= app.start && start <= app.end) || (end <= app.start && end >= app.end))
                            {
                               valid = false;
                               MessageBoxResult result = MessageBox.Show("Conflicts with another appointment.", "Error", MessageBoxButton.OK);                              

                            }
                        }
                    }
                }

                return valid;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was a validation error. This form will close.", "Error", MessageBoxButton.OK);
                throw ex;
            }
        }

        //saving and editing an appointent record
        private void BtnAddSaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var valid = validateForm();

                if (valid == false)
                {
                    MessageBox.Show("All forms fields are required", "Alert", MessageBoxButton.OK);
                }

                if (valid == true && appointId == 0)
                {
                    AppointmentData apt = new AppointmentData();                    
                    //simplified method to search customer ID number from customer Name to store appropriate data to the customer table in the database
                    var id = listCd.Find(c => c.customerName == ComboAddCName.Text);
                    apt.customerId = id.customerId;
                    apt.contact = TxtAddCPhoneNumber.Text;
                    apt.type = ComboAppType.Text.ToString();
                    //searching user ID to simplify searching data needed to save appointment information
                    var user = listUd.Find(u => u.userName == ComboConsultant.Text);
                    apt.userId = user.userId;
                    apt.start = DateTime.SpecifyKind(start, DateTimeKind.Utc);
                    apt.end = DateTime.SpecifyKind(end, DateTimeKind.Utc);
                    apt.lastUpdateBy = userId.ToString();
                    apt.location = ComboLocation.Text.ToString();                    
                    apt.createdBy = user.userName;
                    DbData data = new DbData();
                    data.insertAppointment(apt);

                    if (valid == true)
                    {
                        this.Close();
                        AppointmentPage ap = new AppointmentPage(userId);
                        ap.ShowDialog();
                    }
                }
                else if (valid == true && appointId != 0)
                {
                    AppointmentData apt = new AppointmentData();
                    apt.appointmentId = appointId;
                    //simplified method to search customer ID number from customer Name to store appropriate data to the customer table in the database
                    var id = listCd.Find(c => c.customerName == ComboAddCName.Text);
                    apt.customerId = id.customerId;
                    apt.contact = TxtAddCPhoneNumber.Text;
                    apt.type = ComboAppType.Text.ToString();
                    //searching user ID to simplify searching data needed to save appointment information
                    var user = listUd.Find(u => u.userName == ComboConsultant.Text);
                    apt.userId = user.userId;
                    apt.start = DateTime.SpecifyKind(start, DateTimeKind.Utc);
                    apt.end = DateTime.SpecifyKind(end, DateTimeKind.Utc);
                    apt.lastUpdateBy = userId.ToString();
                    apt.location = ComboLocation.Text.ToString();
                    DbData data = new DbData();
                    data.updateAppointment(apt);

                    if (valid == true)
                    {
                        this.Close();
                        AppointmentPage ap = new AppointmentPage(userId);
                        ap.ShowDialog();
                    }
                } 
            }
            catch (NullReferenceException nrex)
            {
                MessageBox.Show("Form fields cannot be left blank", "Error", MessageBoxButton.OK);
                throw nrex;
            }
            catch (Exception)
            {
                MessageBox.Show("There was an error saving this data", "Alert", MessageBoxButton.OKCancel, MessageBoxImage.Error);
            }
            //finally
            //{
            //    AppointmentPage ap = new AppointmentPage(userId);
            //    ap.ShowDialog();
            //    this.Close();
            //}
        }


        private DateTime GetDateTime(DateTime date, string time)
        {
            //DateTime newDateTime;
            string delimiter = ":";
            var hour = time.Split(new string[] { delimiter }, StringSplitOptions.None);
            var hr = 0;
            if (time.Contains("PM"))
            {
                if (hour[0] != "12")
                {
                    hr = Convert.ToInt32(hour[0]) + 12;
                }
                else
                {
                    hr = 12;
                }
            }
            else if (time.Contains("AM"))
            {
                hr = Convert.ToInt32(hour[0]);
            }
            date = date.AddHours(Convert.ToDouble(hr));
            var min = hour[1].Substring(0, 2);
            date = date.AddMinutes(Convert.ToDouble(min));

            return date;
        }

        //searching for valid business operating hours
        private bool CheckDateTimeRange(DateTime start, DateTime end)
        {
            bool valid = false;
            var sDay = start.Date;
            var eDay = end.Date;
            var minTime = sDay.AddHours(9);
            var maxTime = eDay.AddHours(17);
            if ((sDay.DayOfWeek == DayOfWeek.Saturday) || (eDay.DayOfWeek == DayOfWeek.Saturday))
            {
                valid = false;
            }
            else if ((sDay.DayOfWeek == DayOfWeek.Sunday) || (eDay.DayOfWeek == DayOfWeek.Sunday))
            {
                valid = false;
            }
            else
            {
                if ((start >= minTime && start <= maxTime) && (end <= maxTime && end >= minTime))
                {
                    valid = true;
                }
                //else
                //{
                //    MessageBox.Show("The scheduled time is outside of business hours. Please adjust the start and end times.", "Error", MessageBoxButton.OK);
                //}
            }

            return valid;
        }

        private void BtnCancelAdd_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            AppointmentPage ap = new AppointmentPage(userId);
            ap.ShowDialog();
        }

        private string ConvertDateTime(DateTime date)
        {
            //string hour = null;
            //if (date.ToString().Contains("AM"))
            //{
            //    hour = $"{date.Hour}:{date.Minute} AM";
            //}
            //else
            //{
            //    hour = $"{date.Hour}:{date.Minute} PM";
            //}

            //return hour;

            string hour = null;
            if (date.ToString().Contains("AM"))
            {
                hour = $"{date.Hour}:{date.Minute} AM";
            }
            else
            {
                var hr = date.Hour;
                hr = hr - 12;
                hour = $"{hr}:{date.Minute} PM";
            }

            return hour;

        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9.-]+");
            e.Handled = regex.IsMatch(e.Text);
        }

    }
}
