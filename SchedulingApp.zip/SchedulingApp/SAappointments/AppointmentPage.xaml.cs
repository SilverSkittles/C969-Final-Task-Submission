﻿using System;
using System.Collections.Generic;
using System.Windows;
using Google.Protobuf.WellKnownTypes;
using SchedulingApp.SAappointments;

namespace SchedulingApp.SAappointments
{
    /// <summary>
    /// Interaction logic for AppointmentPage.xaml
    /// </summary>
    public partial class AppointmentPage : Window
    {
        public int apptId;
        public int userId;
        private List<AppointmentData> apList;
        private List<UserData> listUd;

        public AppointmentPage(int useId)
        {
            InitializeComponent();
                        
            if (useId != 0)
            {
                userId = useId;
            }

            DbData db = new DbData();
            DateTime start = DateTime.UtcNow.Date;
            DateTime end = start.AddDays(365);
            apList = db.GetAppointmentsForDateRange(start, end);
            DgTodaysAppt.ItemsSource = apList;
            listUd = db.GetUserName();

        }

        private void BtnAddAppointment_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            AddAppointment pg = new AddAppointment(0, userId);
            pg.Show();
        }

        private void BtnEditAppointment_Click(object sender, RoutedEventArgs e)
        {
            if(DgTodaysAppt.SelectedItem == null)
            { 
                MessageBox.Show("Please select a row."); 
            }
            if (DgTodaysAppt.SelectedItem != null)
            {
                if (DgTodaysAppt.SelectedItem.ToString() == "{NewItemPlaceholder}")
                {

                    MessageBox.Show("Please select a valid row.");
                }
                else
                {
                    this.Close();
                    AddAppointment pg = new AddAppointment(apptId, userId);
                    pg.Show();
                }
            }
           
        }

        private void BtnDeleteAppointment_Click(object sender, RoutedEventArgs e)
        {
            if ((DgTodaysAppt.SelectedItem == null) || (DgTodaysAppt.SelectedItem.ToString() == "{NewItemPlaceholder}"))
            {
                MessageBox.Show("Please select an appointment to delete", "Alert", MessageBoxButton.OK);
            }
            else
            {
                MessageBoxResult response = MessageBox.Show("Are you sure you want to delete this appointment?", "Warning", MessageBoxButton.YesNo);
                if (response == MessageBoxResult.Yes)
                {
                    DbData data = new DbData();
                    data.deleteAppointment(apptId);
                    DgTodaysAppt.ItemsSource = null;
                    DbData db = new DbData();
                    apList = db.GetAllAppointments();
                    DgTodaysAppt.ItemsSource = apList;
                }
            }
        }

        private void DgTodaysAppt_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (DgTodaysAppt.SelectedItem != null)
            {
                if (DgTodaysAppt.SelectedItem.ToString() == "{NewItemPlaceholder}")
                {

                    MessageBox.Show("Please select a valid row.");
                }
                else
                {
                    AppointmentData curApData = (AppointmentData)DgTodaysAppt.SelectedItem;
                    apptId = curApData.appointmentId;
                                     
                }
            }
        }   
        

    }
}
