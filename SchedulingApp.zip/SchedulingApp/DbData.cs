﻿using Google.Protobuf.WellKnownTypes;
using MySql.Data.MySqlClient;
using SchedulingApp.SAreports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchedulingApp
{
    public class DbData
    {        
        public int CheckUserLogin(string userName, string password)
        {
            var validUser = 0;
            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdUsers = new MySqlCommand("SELECT userId FROM `user` WHERE  userName = @userName AND password = @password;", con);
                    cmdUsers.Parameters.AddWithValue("@userName", userName);
                    cmdUsers.Parameters.AddWithValue("@password", password);
                    using (MySqlDataReader rdUser = cmdUsers.ExecuteReader())
                    {
                        if (rdUser.HasRows)
                        {
                            rdUser.Read();
                            var user = Convert.ToInt32(rdUser["userId"]);
                            validUser = user;
                            rdUser.Close();

                        }
                        else
                        {
                            validUser = 0;
                            rdUser.Close();
                        }
                    }

                    return validUser;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        
        public AppointmentData GetAppointmentReminder(int userId)
        {
            AppointmentData ad = new AppointmentData();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();
                var date = DateTime.Now;
                var min = date.AddMinutes(15);

                var start = Convert.ToDateTime($"{date.Month}/{date.Day}/{date.Year} {date.Hour}:{min.Minute}:00.000");

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdAppt = new MySqlCommand("SELECT * FROM `appointment` a inner join customer c on c.customerId = a.customerId  WHERE  userId = @userId AND start = @start;", con);
                    cmdAppt.Parameters.AddWithValue("@start", start);
                    cmdAppt.Parameters.AddWithValue("@userId", userId);
                    using (MySqlDataReader rdAppt = cmdAppt.ExecuteReader())
                    {
                        if (rdAppt.HasRows)
                        {
                            rdAppt.Read();
                                ad.customerName = rdAppt["customerName"].ToString();
                                ad.appointmentId = Convert.ToInt32(rdAppt["appointmentId"]);
                                ad.customerId = Convert.ToInt32(rdAppt["customerId"]);
                                ad.location = (rdAppt["location"]).ToString();
                                ad.start = Convert.ToDateTime(rdAppt["start"]);
                                ad.end = Convert.ToDateTime(rdAppt["end"]);
                                ad.type = (rdAppt["type"]).ToString();
                                ad.userId = Convert.ToInt32(rdAppt["userId"]);
                                ad.contact = rdAppt["contact"].ToString();
                            rdAppt.Close();
                            return ad;
                        }
                        else
                        {
                            rdAppt.Close();
                            return null;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<AppointmentData> GetUserAppointmentsByUserId(int userId)
        {
            List<AppointmentData> listAD = new List<AppointmentData>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdAppt = new MySqlCommand("SELECT * FROM `appointment` a inner join customer c on c.customerId = a.customerId WHERE  userId = @userId AND start > now();", con);
                    cmdAppt.Parameters.AddWithValue("@userId", userId);                   
                    using (MySqlDataReader rdAppt = cmdAppt.ExecuteReader())
                    {
                        if (rdAppt.HasRows)
                        {
                            while (rdAppt.Read())
                            {
                                AppointmentData ad = new AppointmentData();
                                ad.customerName = (rdAppt["customerName"]).ToString();
                                ad.appointmentId = Convert.ToInt32(rdAppt["appointmentId"]);
                                ad.customerId = Convert.ToInt32(rdAppt["customerId"]);
                                ad.location = (rdAppt["location"]).ToString();
                                ad.start = Convert.ToDateTime(rdAppt["start"]).ToLocalTime();
                                ad.end = Convert.ToDateTime(rdAppt["end"]).ToLocalTime();
                                ad.type = (rdAppt["type"]).ToString();
                                ad.userId = Convert.ToInt32(rdAppt["userId"]);
                                ad.contact = rdAppt["contact"].ToString();
                                listAD.Add(ad);
                            }

                                rdAppt.Close();
                                return listAD;
                        }
                        else
                        {
                            rdAppt.Close();
                            return listAD;
                        }
                    }                    
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<CustomerData> GetCustomerNames()
        {
            List<CustomerData> listCust = new List<CustomerData>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdCust = new MySqlCommand("SELECT customerId, customerName FROM `customer`", con);                    
                    using (MySqlDataReader rCust = cmdCust.ExecuteReader())
                    {
                        if (rCust.HasRows)
                        {
                            while (rCust.Read())
                            {
                                CustomerData ad = new CustomerData();
                                ad.customerName = (rCust["customerName"]).ToString();                                
                                ad.customerId = Convert.ToInt32(rCust["customerId"]);                                
                                listCust.Add(ad);
                            }

                            rCust.Close();
                            return listCust;
                        }
                        else
                        {
                            rCust.Close();
                            return listCust;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
               

        public List<CityData> GetCityData()
        {
            List<CityData> listCity = new List<CityData>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdCust = new MySqlCommand("SELECT cityId, city FROM `city`", con);
                    using (MySqlDataReader rCust = cmdCust.ExecuteReader())
                    {
                        if (rCust.HasRows)
                        {
                            while (rCust.Read())
                            {
                                CityData ad = new CityData();
                                ad.city = (rCust["city"]).ToString();
                                ad.cityId = Convert.ToInt32(rCust["cityId"]);
                                //ad.countryId = Convert.ToInt32(rCust["countryId"]);
                                listCity.Add(ad);
                            }

                            rCust.Close();
                            return listCity;
                        }
                        else
                        {
                            rCust.Close();
                            return listCity;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<CountryData> GetCountryData()
        {
            List<CountryData> listCountry = new List<CountryData>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdCust = new MySqlCommand("SELECT countryId, country FROM `country`", con);
                    using (MySqlDataReader rCust = cmdCust.ExecuteReader())
                    {
                        if (rCust.HasRows)
                        {
                            while (rCust.Read())
                            {
                                CountryData ad = new CountryData();
                                ad.country = (rCust["country"]).ToString();
                                ad.countryId = Convert.ToInt32(rCust["countryId"]);
                                listCountry.Add(ad);
                            }

                            rCust.Close();
                            return listCountry;
                        }
                        else
                        {
                            rCust.Close();
                            return listCountry;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<AddressData> GetAddressData()
        {
            List<AddressData> listAddress = new List<AddressData>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdCust = new MySqlCommand("SELECT address, address2, postalCode, cityId, phone, addressId FROM `address`", con);
                    using (MySqlDataReader rCust = cmdCust.ExecuteReader())
                    {
                        if (rCust.HasRows)
                        {
                            while (rCust.Read())
                            {
                                AddressData ad = new AddressData();
                                ad.address = (rCust["address"]).ToString();
                                ad.address2 = (rCust["address2"]).ToString();
                                ad.postalCode = (rCust["postalCode"]).ToString();
                                ad.cityId = Convert.ToInt32(rCust["cityId"]);
                                ad.phone = (rCust["phone"]).ToString();
                                ad.addressId = Convert.ToInt32(rCust["addressId"]);
                                listAddress.Add(ad);
                            }

                            rCust.Close();
                            return listAddress;
                        }
                        else
                        {
                            rCust.Close();
                            return listAddress;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<string> GetLocations()
        {
            List<string> listLoc = new List<string>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdLoc = new MySqlCommand("SELECT distinct(location) FROM `appointment`", con);
                    using (MySqlDataReader rLoc = cmdLoc.ExecuteReader())
                    {
                        if (rLoc.HasRows)
                        {
                            while (rLoc.Read())
                            {
                                var location = (rLoc["location"]).ToString();                                
                                listLoc.Add(location);
                            }

                            rLoc.Close();
                            return listLoc;
                        }
                        else
                        {
                            rLoc.Close();
                            return listLoc;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<string> GetAppointmentType()
        {
            List<string> listApp = new List<string>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdLoc = new MySqlCommand("SELECT distinct(type) FROM `appointment`", con);
                    using (MySqlDataReader rLoc = cmdLoc.ExecuteReader())
                    {
                        if (rLoc.HasRows)
                        {
                            while (rLoc.Read())
                            {
                                var type = (rLoc["type"]).ToString();
                                listApp.Add(type);
                            }

                            rLoc.Close();
                            return listApp;
                        }
                        else
                        {
                            rLoc.Close();
                            return listApp;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<UserData> GetUserName()
        {
            List<UserData> listUser = new List<UserData>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdUser = new MySqlCommand("SELECT userId, userName FROM `user`", con);
                    using (MySqlDataReader rUser = cmdUser.ExecuteReader())
                    {
                        if (rUser.HasRows)
                        {
                            while (rUser.Read())
                            {
                                UserData ad = new UserData();
                                ad.userName = (rUser["userName"]).ToString();
                                ad.userId = Convert.ToInt32(rUser["userId"]);
                                listUser.Add(ad);
                            }

                            rUser.Close();
                            return listUser;
                        }
                        else
                        {
                            rUser.Close();
                            return listUser;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }


        public string GetCustomerNumber(int customerId)
        {
            string pNumber = null;

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdPhoneNumber = new MySqlCommand("SELECT phone FROM `address` a inner join customer c on c.addressId = a.addressId WHERE c.customerId = @customerId;", con);
                    cmdPhoneNumber.Parameters.AddWithValue("@customerId", customerId);
                    using (MySqlDataReader rdPhoneNumber = cmdPhoneNumber.ExecuteReader())
                    {
                        if (rdPhoneNumber.HasRows)
                        {
                            rdPhoneNumber.Read();
                            pNumber = rdPhoneNumber["phone"].ToString();
                            rdPhoneNumber.Close();

                        }
                    }

                    return pNumber;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public void insertAppointment(AppointmentData apdata)
        {
            
            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdInsert = new MySqlCommand("INSERT INTO appointment (customerId, userId, contact, type, start, end, createDate, createdBy, lastUpdateBy, location) VALUES(@customerId, @userId, @contact, @type, @start, @end, @createDate, @createdBy, @lastUpdateBy, @location);", con);
                    cmdInsert.Parameters.AddWithValue("@customerId", apdata.customerId);
                    cmdInsert.Parameters.AddWithValue("@userId", apdata.userId);
                    cmdInsert.Parameters.AddWithValue("@contact", apdata.contact);
                    cmdInsert.Parameters.AddWithValue("@type", apdata.type);
                    cmdInsert.Parameters.AddWithValue("@start", ReformatDateTime(apdata.start.ToString()));
                    cmdInsert.Parameters.AddWithValue("@end", ReformatDateTime(apdata.end.ToString()));
                    cmdInsert.Parameters.AddWithValue("@createDate", ReformatDateTime(DateTime.Now.ToString())); 
                    cmdInsert.Parameters.AddWithValue("@createdBy", apdata.createdBy);
                    cmdInsert.Parameters.AddWithValue("@lastUpdateBy", apdata.lastUpdateBy);
                    cmdInsert.Parameters.AddWithValue("@location", apdata.location);
                    cmdInsert.ExecuteNonQuery();
                    
                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                throw ex;
            }

        }

        public void insertCustomer(CustomerData cusdata)
        {

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdInsert = new MySqlCommand("INSERT INTO customer (customerName, addressId, active, createdBy, lastUpdateBy) VALUES(@customerName, @addressId, @active, @createdBy, @lastUpdateBy);", con);
                    cmdInsert.Parameters.AddWithValue("@customerName", cusdata.customerName);
                    cmdInsert.Parameters.AddWithValue("@addressId", cusdata.addressId);
                    cmdInsert.Parameters.AddWithValue("@active", 1);
                    cmdInsert.Parameters.AddWithValue("@createdBy", cusdata.createdBy);
                    cmdInsert.Parameters.AddWithValue("@lastUpdateBy", cusdata.lastUpdateBy);
                    cmdInsert.ExecuteNonQuery();

                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                throw ex;
            }
        }

        public int insertAddress(AddressData addata)
        {
            int Id;

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdInsert = new MySqlCommand("INSERT INTO address (address, address2, phone, cityId, postalCode) VALUES (@address, @address2, @phone, @cityId, @postalCode); SELECT LAST_INSERT_ID();", con);            
                    cmdInsert.Parameters.AddWithValue("@address", addata.address);
                    cmdInsert.Parameters.AddWithValue("@address2", addata.address2);
                    cmdInsert.Parameters.AddWithValue("@phone", addata.phone);
                    cmdInsert.Parameters.AddWithValue("@cityId", addata.cityId);
                    cmdInsert.Parameters.AddWithValue("@postalCode", addata.postalCode);
                    Id = Convert.ToInt32(cmdInsert.ExecuteScalar());

                }

                return Id;
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                throw ex;
            }
        }

        public int insertCity(string city, int countryId)
        {
            int Id;
            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdInsert = new MySqlCommand("INSERT INTO city (city, countryId) VALUES(@city, @countryId); SELECT LAST_INSERT_ID();", con);
                    cmdInsert.Parameters.AddWithValue("@city", city);
                    cmdInsert.Parameters.AddWithValue("@countryId", countryId);
                    Id = Convert.ToInt32(cmdInsert.ExecuteScalar());

                }

                return Id;
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                throw ex;
            }
        }

        public void updateAppointment(AppointmentData apdata)
        {
            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdInsert = new MySqlCommand("UPDATE appointment SET customerId = @customerId, userId = @userId, contact = @contact, type = @type, start = @start, end = @end, lastUpdateBy = @lastUpdateBy, location = @location WHERE appointmentId = @appointmentId;", con);
                    cmdInsert.Parameters.AddWithValue("@customerId", apdata.customerId);
                    cmdInsert.Parameters.AddWithValue("@userId", apdata.userId);
                    cmdInsert.Parameters.AddWithValue("@contact", apdata.contact);
                    cmdInsert.Parameters.AddWithValue("@type", apdata.type);
                    cmdInsert.Parameters.AddWithValue("@start", ReformatDateTime(apdata.start.ToString()));
                    cmdInsert.Parameters.AddWithValue("@end", ReformatDateTime(apdata.end.ToString()));               
                    cmdInsert.Parameters.AddWithValue("@lastUpdateBy", apdata.lastUpdateBy);
                    cmdInsert.Parameters.AddWithValue("@location", apdata.location);
                    cmdInsert.Parameters.AddWithValue("@appointmentId", apdata.appointmentId);
                    cmdInsert.ExecuteNonQuery();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void updateCustomer(CustomerData cddata)
        {
            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdInsert = new MySqlCommand("UPDATE customer SET customerName = @customerName, lastUpdateBy = @lastUpdateBy WHERE customerId = @customerId;", con);
                    cmdInsert.Parameters.AddWithValue("@customerId", cddata.customerId);
                    cmdInsert.Parameters.AddWithValue("@customerName", cddata.customerName);
                    cmdInsert.Parameters.AddWithValue("@lastUpdateBy", cddata.lastUpdateBy);
                    cmdInsert.ExecuteNonQuery();

                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                throw ex;
            }
        }

        public void updateAddress(AddressData addata)
        {
            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdInsert = new MySqlCommand("UPDATE `address` SET address = @address, address2 = @address2, phone = @phone, cityId = @cityId, postalCode = @postalCode WHERE addressId = @addressId;", con);
                    cmdInsert.Parameters.AddWithValue("@addressId", addata.addressId);
                    cmdInsert.Parameters.AddWithValue("@address", addata.address);
                    cmdInsert.Parameters.AddWithValue("@address2", addata.address2);
                    cmdInsert.Parameters.AddWithValue("@phone", addata.phone);
                    cmdInsert.Parameters.AddWithValue("@cityId", addata.cityId);
                    cmdInsert.Parameters.AddWithValue("@postalCode", addata.postalCode);
                    cmdInsert.ExecuteNonQuery();

                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                throw ex;
            }
        }


        public AppointmentData getAppointmentByAppointmentId(int appointmentId)
        {
            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();
                AppointmentData ad = new AppointmentData();

                using (con)
                {
                    con.Open();
                    
                    MySqlCommand cmdGet = new MySqlCommand("SELECT * FROM `appointment` a INNER JOIN `customer` c on c.customerId = a.customerId WHERE appointmentId = @appointmentId;", con);
                    cmdGet.Parameters.AddWithValue("@appointmentId", appointmentId);

                    using (MySqlDataReader rAppt = cmdGet.ExecuteReader())
                    {
                        if (rAppt.HasRows)
                        {
                            rAppt.Read();
                            //ad.active = Convert.ToBoolean(rAppt["active"]);
                            ad.userId = Convert.ToInt32(rAppt["userId"]);
                            ad.appointmentId = Convert.ToInt32(rAppt["appointmentId"]);
                            ad.contact = rAppt["contact"].ToString();
                            ad.customerName = rAppt["customerName"].ToString();
                            ad.description = rAppt["description"].ToString();
                            ad.type = rAppt["type"].ToString();
                            ad.location = rAppt["location"].ToString();
                            ad.customerId = Convert.ToInt32(rAppt["customerId"]);
                            ad.start = Convert.ToDateTime(rAppt["start"]).ToUniversalTime();
                            ad.end = Convert.ToDateTime(rAppt["end"]).ToUniversalTime();
                            rAppt.Close();

                        }
                    }                        

                    return ad;

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        
        public CustomerData GetCustomerByCustomerId(int customerId)
        {
            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();
                CustomerData ad = new CustomerData();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdGet = new MySqlCommand("SELECT * FROM `customer` c inner join `address` a on c.addressId = a.addressId inner join `city` e on a.cityId = e.cityId WHERE customerId = @customerId AND active = true;", con);
                    cmdGet.Parameters.AddWithValue("@customerId", customerId);

                    using (MySqlDataReader rAppt = cmdGet.ExecuteReader())
                    {
                        if (rAppt.HasRows)
                        {
                            rAppt.Read();
                            ad.customerId = Convert.ToInt32(rAppt["customerId"]);
                            ad.customerName = (rAppt["customerName"]).ToString();
                            ad.phone = (rAppt["phone"]).ToString();
                            ad.address = rAppt["address"].ToString();
                            ad.address2 = rAppt["address2"].ToString();
                            ad.addressId = Convert.ToInt32(rAppt["addressId"]);
                            ad.city = rAppt["city"].ToString();
                            ad.postalCode = rAppt["postalCode"].ToString();
                            ad.countryId = Convert.ToInt32(rAppt["countryId"]);
                            ad.active = Convert.ToBoolean(rAppt["active"]);
                            ad.createdBy = rAppt["createdBy"].ToString();
                            ad.lastUpdateBy = rAppt["lastUpdateBy"].ToString();
                            rAppt.Close();

                        }
                    }

                    return ad;

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void deleteAppointment(int appointmentId)
        {
            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdDelete = new MySqlCommand("DELETE FROM appointment WHERE appointmentId = @appointmentId;", con);
                    cmdDelete.Parameters.AddWithValue("@appointmentId", appointmentId);
                    cmdDelete.ExecuteNonQuery();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void deleteCustomer(int customerId)
        {
            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdDelete = new MySqlCommand("DELETE FROM customer WHERE customerId = @customerId;", con);
                    cmdDelete.Parameters.AddWithValue("@customerId", customerId);
                    cmdDelete.ExecuteNonQuery();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<AppointmentData> GetAllAppointments()
        {
            List<AppointmentData> listAD = new List<AppointmentData>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    //MySqlCommand cmdAppt = new MySqlCommand("SELECT * FROM `appointment` a inner join customer c on c.customerId = a.customerId inner join user u on a.userId = u.userId WHERE start > NOW();", con);
                    MySqlCommand cmdAppt = new MySqlCommand("SELECT * FROM `appointment` a inner join customer c on c.customerId = a.customerId inner join user u on a.userId = u.userId;", con);
                    using (MySqlDataReader rdAppt = cmdAppt.ExecuteReader())
                    {
                        if (rdAppt.HasRows)
                        {
                            while (rdAppt.Read())
                            {
                                AppointmentData ad = new AppointmentData();
                                ad.customerName = (rdAppt["customerName"]).ToString();
                                ad.appointmentId = Convert.ToInt32(rdAppt["appointmentId"]);
                                ad.customerId = Convert.ToInt32(rdAppt["customerId"]);
                                ad.location = (rdAppt["location"]).ToString();
                                ad.start = Convert.ToDateTime(rdAppt["start"]).ToLocalTime();
                                ad.end = Convert.ToDateTime(rdAppt["end"]).ToLocalTime();
                                ad.type = (rdAppt["type"]).ToString();
                                ad.userId = Convert.ToInt32(rdAppt["userId"]);
                                ad.UserName = (rdAppt["userName"]).ToString();
                                listAD.Add(ad);
                            }

                            rdAppt.Close();
                            return listAD;
                        }
                        else
                        {
                            rdAppt.Close();
                            return listAD;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<AppointmentData> GetAppointmentsForDateRange(DateTime start, DateTime end)
        {
            List<AppointmentData> listAD = new List<AppointmentData>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdAppt = new MySqlCommand("SELECT * FROM `appointment` a inner join customer c on c.customerId = a.customerId inner join user u on a.userId = u.userId WHERE start >= @start AND start < @end;", con);
                    cmdAppt.Parameters.AddWithValue("@start", start);
                    cmdAppt.Parameters.AddWithValue("@end", end);
                    using (MySqlDataReader rdAppt = cmdAppt.ExecuteReader())
                    {
                        if (rdAppt.HasRows)
                        {
                            while (rdAppt.Read())
                            {
                                AppointmentData ad = new AppointmentData();
                                ad.customerName = (rdAppt["customerName"]).ToString();
                                ad.appointmentId = Convert.ToInt32(rdAppt["appointmentId"]);
                                ad.customerId = Convert.ToInt32(rdAppt["customerId"]);
                                ad.location = (rdAppt["location"]).ToString();
                                ad.start = (Convert.ToDateTime(rdAppt["start"])).ToLocalTime();
                                ad.end = (Convert.ToDateTime(rdAppt["end"])).ToLocalTime();
                                ad.type = (rdAppt["type"]).ToString();
                                ad.userId = Convert.ToInt32(rdAppt["userId"]);
                                ad.UserName = (rdAppt["userName"]).ToString();
                                listAD.Add(ad);
                            }

                            rdAppt.Close();
                            return listAD;
                        }
                        else
                        {
                            rdAppt.Close();
                            return listAD;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<CustomerData> GetAllCustomers()
        {
            List<CustomerData> listCd = new List<CustomerData>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdCust = new MySqlCommand("SELECT * FROM `customer` c inner join address a on c.addressId = a.addressId inner join city p on a.cityId = p.cityId WHERE active = 1;", con);
                    using (MySqlDataReader rdCust = cmdCust.ExecuteReader())
                    {
                        if (rdCust.HasRows)
                        {
                            while (rdCust.Read())
                            {
                                CustomerData cd = new CustomerData();
                                cd.customerName = (rdCust["customerName"]).ToString();                                
                                cd.customerId = Convert.ToInt32(rdCust["customerId"]);
                                cd.addressId = Convert.ToInt32(rdCust["addressId"]);
                                cd.active = Convert.ToBoolean(rdCust["active"]);
                                cd.address = (rdCust["address"]).ToString();
                                cd.address2 = (rdCust["address2"]).ToString();
                                cd.cityId = Convert.ToInt32(rdCust["cityId"]);
                                cd.postalCode = (rdCust["postalCode"]).ToString();
                                cd.phone = (rdCust["phone"]).ToString();
                                listCd.Add(cd);
                            }

                            rdCust.Close();
                            return listCd;
                        }
                        else
                        {
                            rdCust.Close();
                            return listCd;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ConsultantReport> GetConsultantReport()
        {
            List<ConsultantReport> listCR = new List<ConsultantReport>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdCust = new MySqlCommand("SELECT u.userName, c.customerName, a.start, a.end from `appointment` a inner join `user` u on a.userId = u.userId inner join `customer` c on a.customerId = c.customerId order by u.username asc, a.start desc;", con);
                    using (MySqlDataReader rdCust = cmdCust.ExecuteReader())
                    {
                        if (rdCust.HasRows)
                        {
                            while (rdCust.Read())
                            {
                                ConsultantReport cd = new ConsultantReport();
                                cd.customerName = (rdCust["customerName"]).ToString();
                                cd.userName = (rdCust["userName"]).ToString();
                                cd.start =(rdCust["start"]).ToString();
                                cd.end =(rdCust["end"]).ToString();                                
                                listCR.Add(cd);
                            }

                            rdCust.Close();
                            return listCR;
                        }
                        else
                        {
                            rdCust.Close();
                            return listCR;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<MonthlyAppointmentReport> GetMonthlyAppointmentReport(DateTime start, DateTime end)
        {
            List<MonthlyAppointmentReport> listAR = new List<MonthlyAppointmentReport>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdCust = new MySqlCommand("SELECT `type`, `location`, count(appointmentId) as 'Total' from `appointment` WHERE start >= @start AND start < @end group by `type` order by `location` asc;", con);
                    cmdCust.Parameters.AddWithValue("@start", start);
                    cmdCust.Parameters.AddWithValue("@end", end);
                    using (MySqlDataReader rdCust = cmdCust.ExecuteReader())
                    {
                        if (rdCust.HasRows)
                        {
                            while (rdCust.Read())
                            {
                                MonthlyAppointmentReport cd = new MonthlyAppointmentReport();
                                cd.type = (rdCust["type"]).ToString();
                                cd.location = (rdCust["location"]).ToString();
                                cd.Total = (rdCust["Total"]).ToString();
                                listAR.Add(cd);
                            }

                            rdCust.Close();
                            return listAR;
                        }
                        else
                        {
                            rdCust.Close();
                            return listAR;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ConsultantAppByNumberReport> GetAppointmentsNumberByConsultantReport(DateTime start, DateTime end)
        {
            List<ConsultantAppByNumberReport> listNR = new List<ConsultantAppByNumberReport>();

            try
            {
                DbConnections dbCon = new DbConnections();
                MySqlConnection con = new MySqlConnection();
                con = dbCon.GetConnection();

                using (con)
                {
                    con.Open();

                    MySqlCommand cmdCust = new MySqlCommand("SELECT u.userName, a.`type`, COUNT(a.appointmentId) as 'Total' from `appointment` a  inner join `user` u on a.userId = u.userId WHERE start >= @start AND start < @end group by u.username, a.`type` order by u.username, a.`type`; ", con);
                    cmdCust.Parameters.AddWithValue("@start", start);
                    cmdCust.Parameters.AddWithValue("@end", end);
                    using (MySqlDataReader rdCust = cmdCust.ExecuteReader())
                    {
                        if (rdCust.HasRows)
                        {
                            while (rdCust.Read())
                            {
                                ConsultantAppByNumberReport cd = new ConsultantAppByNumberReport();
                                cd.type = (rdCust["type"]).ToString();
                                cd.userName = (rdCust["userName"]).ToString();
                                cd.Total = (rdCust["Total"]).ToString();
                                listNR.Add(cd);
                            }

                            rdCust.Close();
                            return listNR;
                        }
                        else
                        {
                            rdCust.Close();
                            return listNR;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }


        //gentereates database entries automatically on first run
        public void PopulateDatabaseFirstTime()
        {
            var check = CheckForData();
            //CheckForData();
            if (check == false)
            {
                try
                {
                    DbConnections dbCon = new DbConnections();
                    MySqlConnection con = new MySqlConnection();
                    con = dbCon.GetConnection();

                    using (con)
                    {
                        con.Open();

                        MySqlCommand cmdCat = new MySqlCommand("INSERT INTO `country` VALUES (1, 'US', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'), (2, 'Canada', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'), (3, 'Norway', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test');" +
                                                               "INSERT INTO `city` VALUES (1, 'New York', 1, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'), (2, 'Los Angeles', 1, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'),(3, 'Toronto', 2, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'), (4, 'Vancouver', 2, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'), (5, 'Oslo', 3, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'); " +
                                                               "INSERT INTO `address` VALUES (1, '123 Main', '', 1, '11111', '555-1212', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'), (2, '123 Elm', '', 3, '11112', '555-1213', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'), (3, '123 Oak', '', 5, '11113', '555-1214', '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test');" +
                                                               "INSERT INTO `customer` VALUES (1, 'John Doe', 1, 1, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'), (2, 'Alfred E Newman', 2, 1, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'), (3, 'Ina Prufung', 3, 1, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'); " +
                                                               "INSERT INTO `user` VALUES (1, 'test', 'test', 1, '2019-01-01 00:00:00', 'test', '2019-01-01 00:00:00', 'test'); " +
                                                               "INSERT INTO `appointment` VALUES (1, 1, 1, 'not needed', 'not needed', 'not needed', 'not needed', 'not needed', 'Presentation', '2020-05-31 00:00:00', '2020-05-31 00:00:00', '2020-05-01 00:00:00', 'test', '2020-05-01 00:00:00', 'test'), (2, 2, 1, 'not needed', 'not needed', 'not needed', 'not needed', 'Scrum', 'not needed', '2020-06-01 00:00:00', '2020-06-01 00:00:00', '2020-05-01 00:00:00', 'test', '2020-05-01 00:00:00', 'test');", con);
                        cmdCat.ExecuteNonQuery();
                    }
                }

                catch (Exception ex)
                {
                    throw ex;
                }
            }           
        }

        public bool CheckForData()
        {
            bool checkDb = false;
            DbConnections dbCon = new DbConnections();
            MySqlConnection con = new MySqlConnection();
            con = dbCon.GetConnection();

            using (con)
            {
                con.Open();

                MySqlCommand cmdChk = new MySqlCommand("SELECT userName from `user` WHERE userName = 'test';", con);
                using (MySqlDataReader rdChk = cmdChk.ExecuteReader())
                {
                    if (rdChk.HasRows)
                    {
                        rdChk.Close();
                        checkDb = true;
                    }
                    else
                    {
                        rdChk.Close();
                        checkDb = false;
                    }
                }

                return checkDb;
            }          

        }

        public string ReformatDateTime(string date)
        {
            if (date != null)
            {
                DateTime dateValue = DateTime.Parse(date);
                string MySQlDate = dateValue.ToUniversalTime().ToString("yyyy-MM-dd H:mm:ss");
                return MySQlDate;
            }
            else
            {
                return null;
            }
        }
    }
}

