﻿namespace SchedulingApp
{
    partial class FrmCalendar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            this.radioMonth = new System.Windows.Forms.RadioButton();
            this.radioWeek = new System.Windows.Forms.RadioButton();
            this.monthlyCalendar = new System.Windows.Forms.MonthCalendar();
            this.DgAppointmentCalendar = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DgAppointmentCalendar)).BeginInit();
            this.SuspendLayout();
            // 
            // radioMonth
            // 
            this.radioMonth.AutoSize = true;
            this.radioMonth.Location = new System.Drawing.Point(291, 60);
            this.radioMonth.Name = "radioMonth";
            this.radioMonth.Size = new System.Drawing.Size(88, 17);
            this.radioMonth.TabIndex = 0;
            this.radioMonth.TabStop = true;
            this.radioMonth.Text = "Monthly View";
            this.radioMonth.UseVisualStyleBackColor = true;
            // 
            // radioWeek
            // 
            this.radioWeek.AutoSize = true;
            this.radioWeek.Location = new System.Drawing.Point(292, 106);
            this.radioWeek.Name = "radioWeek";
            this.radioWeek.Size = new System.Drawing.Size(87, 17);
            this.radioWeek.TabIndex = 1;
            this.radioWeek.TabStop = true;
            this.radioWeek.Text = "Weekly View";
            this.radioWeek.UseVisualStyleBackColor = true;
            this.radioWeek.Click += new System.EventHandler(this.radioWeek_Click);
            // 
            // monthlyCalendar
            // 
            this.monthlyCalendar.Location = new System.Drawing.Point(12, 41);
            this.monthlyCalendar.Name = "monthlyCalendar";
            this.monthlyCalendar.ShowWeekNumbers = true;
            this.monthlyCalendar.TabIndex = 2;
            this.monthlyCalendar.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthlyCalendar_DateChanged);
            this.monthlyCalendar.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthlyCalendar_DateSelected);
            // 
            // DgAppointmentCalendar
            // 
            this.DgAppointmentCalendar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgAppointmentCalendar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.DgAppointmentCalendar.Location = new System.Drawing.Point(12, 215);
            this.DgAppointmentCalendar.Name = "DgAppointmentCalendar";
            this.DgAppointmentCalendar.Size = new System.Drawing.Size(776, 189);
            this.DgAppointmentCalendar.TabIndex = 3;
            this.DgAppointmentCalendar.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgAppointmentCalendar_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.ActiveLinkColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.Color.White;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle31;
            this.Column1.HeaderText = "Customer Name";
            this.Column1.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.Color.Blue;
            this.Column2.DefaultCellStyle = dataGridViewCellStyle32;
            this.Column2.HeaderText = "Appointment Type";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 150;
            // 
            // Column3
            // 
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.Color.Blue;
            this.Column3.DefaultCellStyle = dataGridViewCellStyle33;
            this.Column3.HeaderText = "Location";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.Color.White;
            this.Column4.DefaultCellStyle = dataGridViewCellStyle34;
            this.Column4.HeaderText = "Start";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 200;
            // 
            // Column5
            // 
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.Blue;
            this.Column5.DefaultCellStyle = dataGridViewCellStyle35;
            this.Column5.HeaderText = "End";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 200;
            // 
            // FrmCalendar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(800, 611);
            this.Controls.Add(this.DgAppointmentCalendar);
            this.Controls.Add(this.monthlyCalendar);
            this.Controls.Add(this.radioWeek);
            this.Controls.Add(this.radioMonth);
            this.HelpButton = true;
            this.KeyPreview = true;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(400, 650);
            this.Name = "FrmCalendar";
            ((System.ComponentModel.ISupportInitialize)(this.DgAppointmentCalendar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioMonth;
        private System.Windows.Forms.RadioButton radioWeek;
        public System.Windows.Forms.MonthCalendar monthlyCalendar;
        private System.Windows.Forms.DataGridView DgAppointmentCalendar;
        private System.Windows.Forms.DataGridViewLinkColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
    }
}