﻿using SchedulingApp.SAcustomer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;

namespace SchedulingApp
{
    public partial class FrmCalendar : Form
    {
        private List<AppointmentData> listAppt = new List<AppointmentData>();
        private List<CustomerData> listCust = new List<CustomerData>();
        private int user;
        public FrmCalendar(int userId)
        {
            InitializeComponent();

            user = userId;

            DbData db = new DbData();
            listAppt = db.GetAllAppointments();
            listCust = db.GetAllCustomers();                   

            DateTime[] appts = new DateTime[listAppt.Count];
            for (int x = 0; x < listAppt.Count; x++)
            {
                appts[x] = new DateTime(listAppt[x].start.Year, listAppt[x].start.Month, listAppt[x].start.Day, listAppt[x].start.Hour, listAppt[x].start.Minute, listAppt[x].start.Second, listAppt[x].start.Millisecond);
            }
            monthlyCalendar.AnnuallyBoldedDates = appts;
            radioMonth.Checked = true;

            this.monthlyCalendar.FirstDayOfWeek = System.Windows.Forms.Day.Sunday;
            this.monthlyCalendar.ShowWeekNumbers = true;
            this.monthlyCalendar.ShowTodayCircle = true;

        }

        private void monthlyCalendar_DateChanged(object sender, DateRangeEventArgs e)
        {
            DbData data = new DbData();
            var dateSelected = e.Start.ToShortDateString();

            if (radioMonth.Checked == true)
            {
                var start = Convert.ToDateTime($"{e.Start.Month}/01/{e.Start.Year}");
                var end = Convert.ToDateTime($"{e.Start.AddMonths(1).Month}/01/{e.Start.Year}");
                var appt = data.GetAppointmentsForDateRange(start, end);
                //var appt = listAppt.FindAll(a => a.start.ToShortDateString() == dateSelected);
                DgAppointmentCalendar.Rows.Clear();
                DgAppointmentCalendar.Columns[0].Name = "Customer Name";
                DgAppointmentCalendar.Columns[1].Name = "Appointment Type";
                DgAppointmentCalendar.Columns[2].Name = "Start";
                DgAppointmentCalendar.Columns[3].Name = "End";
                DgAppointmentCalendar.Columns[4].Name = "Location";

                foreach (var a in appt)
                {
                    DgAppointmentCalendar.Rows.Add(a.customerName, a.appointmentId, a.start, a.end, a.location);
                }
            }
            else
            {
                var start = GetSundayOfWeek(e.Start);
                var end = start.AddDays(6);
                monthlyCalendar.SelectionRange = new SelectionRange(start, end);
                var listApp = data.GetAppointmentsForDateRange(start, end);
                LoadWeek(listApp);
            }
        }

        private void monthlyCalendar_DateSelected(object sender, DateRangeEventArgs e)
        {
            DbData data = new DbData();
            var dateSelected = e.Start.ToShortDateString();

            if (radioMonth.Checked == true)
            {
                var start = Convert.ToDateTime($"{e.Start.Month}/01/{e.Start.Year}");
                var end = Convert.ToDateTime($"{e.Start.AddMonths(1).Month}/01/{e.Start.Year}");
                var appt = data.GetAppointmentsForDateRange(start, end);
                //var appt = listAppt.FindAll(a => a.start.ToShortDateString() == dateSelected);
                DgAppointmentCalendar.Rows.Clear();
                DgAppointmentCalendar.Columns[0].Name = "Customer Name";
                DgAppointmentCalendar.Columns[1].Name = "Appointment Type";
                DgAppointmentCalendar.Columns[2].Name = "Start";
                DgAppointmentCalendar.Columns[3].Name = "End";
                DgAppointmentCalendar.Columns[4].Name = "Location";

                foreach (var a in appt)
                {
                    DgAppointmentCalendar.Rows.Add(a.customerName, a.appointmentId, a.start, a.end, a.location);
                }
            }
            else
            {
                var start = GetSundayOfWeek(e.Start);
                var end = start.AddDays(6);
                var listApp = data.GetAppointmentsForDateRange(start, end);
                LoadWeek(listApp);
            }
        }

        private void DgAppointmentCalendar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            var cust = DgAppointmentCalendar.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
            DbData data = new DbData();
            var listCd = data.GetAllCustomers();
            var customer = listCd.Find(c => c.customerName == cust); //simplifies searching each matching customer record
            CustomerAdd ca = new CustomerAdd(customer.customerId, user);
            ca.Show();            
        }

        private DateTime GetSundayOfWeek(DateTime date)
        {
            DateTime sunday = new DateTime();
            var dayOfWeek = date.DayOfWeek;

            switch (dayOfWeek.ToString())
            {
                case "Sunday":
                    sunday = date;
                    break;
                case "Monday":
                    sunday = date.AddDays(-1);
                    break;
                case "Tuesday":
                    sunday = date.AddDays(-2);
                    break;
                case "Wednesday":
                    sunday = date.AddDays(-3);
                    break;
                case "Thursday":
                    sunday = date.AddDays(-4);
                    break;
                case "Friday":
                    sunday = date.AddDays(-5);
                    break;
                case "Saturday":
                    sunday = date.AddDays(-6);
                    break;
            }
            return sunday;
        }
        private void LoadWeek(List<AppointmentData> listApp)
        {
            DgAppointmentCalendar.Rows.Clear();
            DgAppointmentCalendar.Columns[0].Name = "Customer Name";
            DgAppointmentCalendar.Columns[1].Name = "Appointment Type";
            DgAppointmentCalendar.Columns[2].Name = "Start";
            DgAppointmentCalendar.Columns[3].Name = "End";
            DgAppointmentCalendar.Columns[4].Name = "Location";

            foreach (var a in listApp)
            {
                DgAppointmentCalendar.Rows.Add(a.customerName, a.appointmentId, a.start, a.end, a.location);
            }
        }
        private void dgvMonth_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var cust = DgAppointmentCalendar.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();

            var customer = listCust.Find(c => c.customerName == cust);

            CustomerAdd ca = new CustomerAdd(customer.customerId, user);
            ca.Show();
        }

        private void radioWeek_Click(object sender, EventArgs e)
        {
            radioWeek.Checked = true;

            DateTime start = new DateTime(2020, 4, 26);
            DateTime end = new DateTime(2021, 5, 2);
            monthlyCalendar.SelectionRange = new SelectionRange(start, end);

            DbData data = new DbData();
            var listWeek = data.GetAppointmentsForDateRange(start, end);

            DgAppointmentCalendar.Rows.Clear();
            DgAppointmentCalendar.Columns[0].Name = "Customer Name";
            DgAppointmentCalendar.Columns[1].Name = "Appointment Type";
            DgAppointmentCalendar.Columns[2].Name = "Start";
            DgAppointmentCalendar.Columns[3].Name = "End";
            DgAppointmentCalendar.Columns[4].Name = "Location";

            foreach (var a in listWeek)
            {
                DgAppointmentCalendar.Rows.Add(a.customerName, a.appointmentId, a.start, a.end, a.location);
            }
        }
    }
}
