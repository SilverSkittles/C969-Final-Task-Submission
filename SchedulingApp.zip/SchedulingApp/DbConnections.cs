﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchedulingApp
{
    public class DbConnections
    {
        public MySqlConnection GetConnection()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["myconnection"].ConnectionString;
            MySqlConnection con = new MySqlConnection(connectionString);            
            return con;
        }
    }
}
