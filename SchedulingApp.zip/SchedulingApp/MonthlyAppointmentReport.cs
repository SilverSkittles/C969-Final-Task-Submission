﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchedulingApp
{
    public class MonthlyAppointmentReport
    {
        public string type { get; set; }
        public string location { get; set; }
        public string Total { get; set; }
    }
}
