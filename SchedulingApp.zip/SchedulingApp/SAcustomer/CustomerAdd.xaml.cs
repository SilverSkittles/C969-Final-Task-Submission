﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MessageBox = System.Windows.MessageBox;
using System.Text.RegularExpressions;
using System.CodeDom;

namespace SchedulingApp.SAcustomer
{
    /// <summary>
    /// Interaction logic for CustomerAdd.xaml
    /// </summary>
    public partial class CustomerAdd : Window
    {
        private List<CustomerData> listCd;
        private List<AddressData> listAd;
        private List<CityData> listCity;
        private List<UserData> listUd;
        private List<CountryData> listCountry;
        private int customerId;
        private int userId;
        private int addressId;        
        
        public CustomerAdd(int custId, int useId)
        {
            InitializeComponent();

            if (useId != 0)
            {
                userId = useId;
            }

            DbData data = new DbData();

            listCd = data.GetCustomerNames();
            listUd = data.GetUserName();
            listCity = data.GetCityData();
            listAd = data.GetAddressData();
            listCountry = data.GetCountryData();

            LoadComboboxCountries(listCountry);

            if (custId != 0)
            {
                Add_Edit_Customer.Content = "Edit Existing Customer";
                customerId = custId;
                CustomerData ad = new CustomerData();
                ad = data.GetCustomerByCustomerId(customerId);
                LoadEditCustomer(ad);
            }

        }

        //loads appointment record for editing
        private void LoadEditCustomer(CustomerData ad)
        {
            TxtCustomerName.Text = ad.customerName;
            TxtCPhoneNumber.Text = ad.phone;
            TxtCAddress.Text = ad.address;
            TxtCAddress2.Text = ad.address2;
            TxtCCity.Text = ad.city;
            TxtCZip.Text = ad.postalCode;            
            addressId = ad.addressId;
            var ctry = listCountry.Find(cu => cu.countryId == ad.countryId); //simplified search for country data by the country ID
            ComboCountry.Text = ctry.country;
        }

        private void LoadComboboxCountries(List<CountryData> listCountry)
        {
            foreach (var l in listCountry)
            {
                ComboCountry.Items.Add(l.country);
            }
        }

        private void CancelCustomer_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            CustomerMain cm = new CustomerMain(userId);
            cm.ShowDialog();
        }

        private void SaveCustomer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var valid = validateForm();
                if (valid == true && customerId == 0)
                {
                    CustomerData cus = new CustomerData();
                    AddressData addy = new AddressData();
                    //simplified method to search customer duplicates before adding entry                   
                    var nameSearch = listCd.Exists(c => c.customerName.ToUpper() == TxtCustomerName.Text.ToUpper());
                    
                    //check for existing customer name to avoid duplicates, figure out customer ID for new entries                    
                    if (nameSearch == true)
                    {
                        MessageBox.Show("Alert", "This customer already exists", MessageBoxButton.OK);
                    }
                    else
                    {   
                        //inserting new customer

                        var cId = listCity.Find(a => a.city == TxtCCity.Text);
                        if(cId != null)
                        {

                            DbData data = new DbData();
                            //simplified search for city ID from a joined data table
                            cus.customerName = TxtCustomerName.Text;
                            addy.cityId = cId.cityId;
                            addy.phone = TxtCPhoneNumber.Text.ToString();
                            addy.address = TxtCAddress.Text.ToString();
                            addy.address2 = TxtCAddress2.Text.ToString();
                            addy.postalCode = TxtCZip.Text.ToString();
                            addy.country = ComboCountry.Text.ToString();
                            //simplified search for country data by the country ID
                            var ctry = listCountry.Find(cu => cu.country == ComboCountry.Text);
                            addy.countryId = ctry.countryId;
                            cus.lastUpdateBy = userId.ToString();
                            addy.lastUpdateBy = userId.ToString();
                            //simplified search for the user name of the person who created the customer entry
                            var user = listUd.Find(u => u.userId == userId);
                            cus.createdBy = user.userName;
                            addy.createdBy = user.userName;
                            var aId = data.insertAddress(addy);
                            cus.addressId = aId;
                            data.insertCustomer(cus);
                        }
                        else
                        {
                            DbData data = new DbData();
                            cus.customerName = TxtCustomerName.Text;
                            addy.city = TxtCCity.Text;
                            addy.phone = TxtCPhoneNumber.Text.ToString();
                            addy.address = TxtCAddress.Text.ToString();
                            addy.address2 = TxtCAddress2.Text.ToString();
                            addy.postalCode = TxtCZip.Text.ToString();
                            //simplified search for country data by the country ID
                            var ctry = listCountry.Find(cu => cu.country == ComboCountry.Text);
                            addy.countryId = ctry.countryId;
                            var cityId = data.insertCity(TxtCCity.Text, ctry.countryId);
                            cus.lastUpdateBy = userId.ToString();
                            addy.lastUpdateBy = userId.ToString();
                            //simplified search for the user name of the person who created the customer entry
                            var user = listUd.Find(u => u.userId == userId);
                            cus.createdBy = user.userName;
                            addy.createdBy = user.userName;
                            var aId = data.insertAddress(addy);
                            cus.addressId = aId;
                            data.insertCustomer(cus);                            
                        }
                        if (valid == true)
                        {
                            this.Close();
                            CustomerMain cp = new CustomerMain(userId);
                            cp.ShowDialog();
                        }
                    }                    
                }
                else if (valid == true && customerId != 0)
                {
                    //updating existing customer

                    CustomerData cus = new CustomerData();
                    AddressData addy = new AddressData();
                    DbData data = new DbData();
                    //simplified search for city ID and country ID from a joined data table
                    var cId = listCity.Find(a => a.city == TxtCCity.Text);
                    var ctry = listCountry.Find(cu => cu.country == ComboCountry.Text);
                    if (cId != null)
                    {                        
                        addy.cityId = cId.cityId;                      

                    }
                    if (ctry != null)
                    {
                        addy.countryId = ctry.countryId;
                    }                   
                    else
                    {
                        addy.cityId = data.insertCity(TxtCCity.Text, ctry.countryId);
                    }

                    cus.customerId = customerId;
                    cus.customerName = TxtCustomerName.Text;
                    addy.phone = TxtCPhoneNumber.Text.ToString();
                    addy.addressId = addressId;
                    cus.addressId = addressId;
                    addy.address = TxtCAddress.Text.ToString();
                    addy.address2 = TxtCAddress2.Text.ToString();
                    addy.postalCode = TxtCZip.Text.ToString();
                    cus.lastUpdateBy = userId.ToString();
                    addy.lastUpdateBy = userId.ToString();
                    //simplified search for the user name of the person who created the customer entry
                    var user = listUd.Find(u => u.userId == userId);
                    cus.createdBy = user.userName;
                    addy.createdBy = user.userName;
                    data.updateAddress(addy);
                    data.updateCustomer(cus);   
                    
                    if (valid == true)
                    {
                        this.Close();
                        CustomerMain cp = new CustomerMain(userId);
                        cp.ShowDialog();
                    }
                }  
            }
            catch (NullReferenceException nrex)
            {
                MessageBox.Show("Form fields cannot be left blank", "Error", MessageBoxButton.OK);
                throw nrex;
            }
            catch (Exception)
            {
                MessageBox.Show("There was an error saving this data", "Alert", MessageBoxButton.OKCancel, MessageBoxImage.Error);
            }
        }


        //form validation
        private bool validateForm()
        {            
            bool valid = true;

            try
            {
                if (String.IsNullOrEmpty(TxtCustomerName.Text))
                    valid = false;
                if (String.IsNullOrEmpty(TxtCPhoneNumber.Text))
                    valid = false;
                if (String.IsNullOrEmpty(TxtCAddress.Text))
                    valid = false;
                if (String.IsNullOrEmpty(TxtCCity.Text))
                    valid = false;
                if (String.IsNullOrEmpty(TxtCZip.Text))
                    valid = false;
                if (String.IsNullOrEmpty(ComboCountry.Text))
                    valid = false;

                if(valid == false)
                {
                    MessageBox.Show("All forms fields are required", "Alert", MessageBoxButton.OK);
                }
                return valid;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was a validation error.", "Error", MessageBoxButton.OK);
                throw ex;
            }
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9.-]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void NumberValidationTextBox2(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
