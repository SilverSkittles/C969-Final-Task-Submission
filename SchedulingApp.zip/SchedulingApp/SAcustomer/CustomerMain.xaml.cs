﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SchedulingApp.SAcustomer
{
    /// <summary>
    /// Interaction logic for CustomerMain.xaml
    /// </summary>
    public partial class CustomerMain : Window
    {
        public int custId;
        public int userId;
        private List<CustomerData> cdList;
        public CustomerMain(int useId)
        {
            InitializeComponent();
            DbData db = new DbData();
            cdList = db.GetAllCustomers();
            DgCustomersList.ItemsSource = cdList;

            if (useId != 0)
            {
                userId = useId;
            }
        }

        private void BtnAddCustomer_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            CustomerAdd pg = new CustomerAdd(0, userId);
            pg.Show();
        }

        private void BtnEditCustomer_Click(object sender, RoutedEventArgs e)
        {            
            if(DgCustomersList.SelectedItem == null)
            {
                MessageBox.Show("Please select a row.");
            }
            else if (DgCustomersList.SelectedItem != null)
            {
                if (DgCustomersList.SelectedItem.ToString() == "{NewItemPlaceholder}")
                {
                    MessageBox.Show("Please select a valid row.");
                }
                else
                {
                    this.Close();
                    CustomerAdd pg = new CustomerAdd(custId, userId);
                    pg.Show();
                }
            }                
        }

        private void BtnDeleteCustomer_Click(object sender, RoutedEventArgs e)
        {

            if (DgCustomersList.SelectedItem == null)
            {
                MessageBox.Show("Please select a customer record.");
            }
            else
            {
                MessageBoxResult response = MessageBox.Show("Are you sure you want to delete this customer?", "Warning", MessageBoxButton.YesNo);
                if (response == MessageBoxResult.Yes)
                {
                    DbData data = new DbData();
                    data.deleteCustomer(custId);
                    DgCustomersList.ItemsSource = null;
                    DbData db = new DbData();
                    cdList = db.GetAllCustomers();
                    DgCustomersList.ItemsSource = cdList;
                }
            }
        }

        private void DgCustomersList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DgCustomersList.SelectedItem != null)
            {
                if (DgCustomersList.SelectedItem.ToString() == "{NewItemPlaceholder}")
                {

                    MessageBox.Show("Please select a valid row.");
                }
                else
                {
                    CustomerData curApData = (CustomerData)DgCustomersList.SelectedItem;
                    custId = curApData.customerId;
                }
            }
        }
    }
}
