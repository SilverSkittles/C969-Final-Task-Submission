﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SchedulingApp.SAreports
{
    /// <summary>
    /// Interaction logic for NumberAppointmentByConsultant.xaml
    /// </summary>
    public partial class NumberAppointmentByConsultant : Window
    {  
        public NumberAppointmentByConsultant()
        {
            InitializeComponent();

            var start = Convert.ToDateTime(DateTime.Now.Month + "/1/" + DateTime.Now.Year);
            var end = start.AddMonths(1);
            DbData data = new DbData();
            var report = data.GetAppointmentsNumberByConsultantReport(start, end);
            DgConsultNumber.ItemsSource = report;
        }
    }
}
