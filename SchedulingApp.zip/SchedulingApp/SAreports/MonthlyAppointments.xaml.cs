﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SchedulingApp.SAreports
{
    /// <summary>
    /// Interaction logic for MonthlyAppointments.xaml
    /// </summary>
    public partial class MonthlyAppointments : Window
    {
        public MonthlyAppointments()
        {
            InitializeComponent();

            //intialtizes the selection items for the report combo box
            ComboMonthlyReport.Items.Add("January");
            ComboMonthlyReport.Items.Add("February");
            ComboMonthlyReport.Items.Add("March");
            ComboMonthlyReport.Items.Add("April");
            ComboMonthlyReport.Items.Add("May");
            ComboMonthlyReport.Items.Add("June");
            ComboMonthlyReport.Items.Add("July");
            ComboMonthlyReport.Items.Add("August");
            ComboMonthlyReport.Items.Add("September");
            ComboMonthlyReport.Items.Add("October");
            ComboMonthlyReport.Items.Add("November");
            ComboMonthlyReport.Items.Add("December");

            var start = Convert.ToDateTime(DateTime.Now.Month + "/1/" + DateTime.Now.Year);
            var end = start.AddMonths(1);
            DbData data = new DbData();
            var report = data.GetMonthlyAppointmentReport(start, end);
            DgMonthlyReport.ItemsSource = report;
        }

        private void ComboMonthlyReport_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selection = ComboMonthlyReport.SelectedItem.ToString();
            string month = null;       

            switch (selection)
            {
                case "January":
                    month = "1";
                    break;
                case "February":
                    month = "2";
                    break;
                case "March":
                    month = "3";
                    break;
                case "April":
                    month = "4";
                    break;
                case "May":
                    month = "5";
                    break;
                case "June":
                    month = "6";
                    break;
                case "July":
                    month = "7";
                    break;
                case "August":
                    month = "8";
                    break;
                case "September":
                    month = "9";
                    break;
                case "October":
                    month = "10";
                    break;
                case "November":
                    month = "11";
                    break;
                case "December":
                    month = "12";
                    break;
            }

            DgMonthlyReport.ItemsSource = null;
            var start = Convert.ToDateTime(month + "/1/" + DateTime.Now.Year);
            var end = start.AddMonths(1);
            DbData data = new DbData();
            var report = data.GetMonthlyAppointmentReport(start, end);
            DgMonthlyReport.ItemsSource = report;
        }
    }
}

