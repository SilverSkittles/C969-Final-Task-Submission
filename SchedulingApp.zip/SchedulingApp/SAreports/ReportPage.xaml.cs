﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SchedulingApp.SAreports
{
    /// <summary>
    /// Interaction logic for ReportPage.xaml
    /// </summary>
    public partial class ReportPage : Window
    {
        public ReportPage()
        {
            InitializeComponent();
        }

        private void BtnConsultSchedule_Click(object sender, RoutedEventArgs e)
        {
            ConsultantSchedules cs = new ConsultantSchedules();
            cs.Show();
        }

        private void BtnMonthlyApp_Click(object sender, RoutedEventArgs e)
        {
            MonthlyAppointments ma = new MonthlyAppointments();
            ma.Show();
        }

        private void BtnAppByConsult_Click(object sender, RoutedEventArgs e)
        {
            NumberAppointmentByConsultant ac = new NumberAppointmentByConsultant();
            ac.Show();
        }
    }
}
