﻿using SchedulingApp.SAcustomer;
using SchedulingApp.SAreports;
using SchedulingApp.SAappointments;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Timers;
using Ubiety.Dns.Core.Records.Mail;

namespace SchedulingApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static int userId;
        private int currentSelect;
        private static Timer reminderTimer;
        public MainWindow()
        {
            InitializeComponent();
            LogIn logIn = new LogIn();
            logIn.ShowDialog();

            DbData db = new DbData();
            List<AppointmentData> ad = db.GetUserAppointmentsByUserId(userId);
            DgTodaySchedule.ItemsSource = ad;

            SetTimer();

            //CollectionViewSource apptCollectionViewSource;
            //apptCollectionViewSource = (CollectionViewSource)(FindResource("ApptCollectionViewSource"));
            //apptCollectionViewSource.Source = ad;

        }

        private static void SetTimer()
        {
            //Timer with a thirty second interval.
            reminderTimer = new System.Timers.Timer(30000);
            reminderTimer.Elapsed += OnTimedEvent;
            reminderTimer.AutoReset = true;
            reminderTimer.Enabled = true;
        }

        private static void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            DbData data = new DbData();
            var reminder = data.GetAppointmentReminder(userId);
            if (reminder != null)
            {
                MessageBox.Show($"You have a scheduled appointment at {reminder.start}", "Alert", MessageBoxButton.OK);
            }
        }

        public void getUserId(int user)
        {
            userId = user;
        }

        private void DgTodaySchedule_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DgTodaySchedule.SelectedItem != null)
            {
                if (DgTodaySchedule.SelectedItem.ToString() == "{NewItemPlaceholder}")
                {

                    MessageBox.Show("Please select a valid row.");
                }
                else
                {
                    AppointmentData curSchedRow = (AppointmentData)DgTodaySchedule.SelectedItem;
                    currentSelect = curSchedRow.appointmentId;
                }
            }
        }

        private void BtnCustomerInfo_Click(object sender, RoutedEventArgs e)
        {
            CustomerMain cp = new CustomerMain(userId);
            cp.ShowDialog();
        }
        private void BtnAppointments_Click(object sender, RoutedEventArgs e)
        {
            AppointmentPage ap = new AppointmentPage(userId);
            ap.ShowDialog();

        }

        private void BtnReports_Click(object sender, RoutedEventArgs e)
        {
            ReportPage rp = new ReportPage();
            rp.ShowDialog();
        }

        private void BtnCalendar_Click(object sender, RoutedEventArgs e)
        {
            FrmCalendar calendar = new FrmCalendar(userId);
            calendar.Show();
        }
    }
}
