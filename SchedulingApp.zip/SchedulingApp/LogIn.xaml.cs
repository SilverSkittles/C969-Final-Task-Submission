﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SchedulingApp
{
    /// <summary>
    /// Interaction logic for LogIn.xaml
    /// </summary>
    public partial class LogIn : Window
    {
        bool loginSuccess = false;
        public LogIn()
        {
            InitializeComponent();

            //if (RegionInfo.CurrentRegion.NativeName == "Mexico")
            //{
            //    LabelHeader.Content = "PorFavor Iniciar Sesión Abajo";
            //    LabelPassword.Content = "Contraseña";
            //    LabelUsername.Content = "Nombre de usuario";
            //    //LabelLanguage.Content = "Seleccione un idioma";
            //    LoginSubmit.Content = "Enviar";
            //    LoginCancel.Content = "Cancelar";
            //}

            DbData data = new DbData();
            data.PopulateDatabaseFirstTime();

            if (RegionInfo.CurrentRegion.NativeName == "France")
            {
                LabelHeader.Content = "Veuillez vous connecter ci-dessous";
                LabelPassword.Content = "Mot de passe";
                LabelUsername.Content = "Nom d'utilisateur";
                LoginSubmit.Content = "Soumettre";
                LoginCancel.Content = "Annuler";
            }
            else if(RegionInfo.CurrentRegion.EnglishName == "United States")
            {
                LabelHeader.Content = "Please Log In Below";
                LabelPassword.Content = "Password";
                LabelUsername.Content = "Username";
                LoginSubmit.Content = "Submit";
                LoginCancel.Content = "Cancel";
            }

            
        }


        private void LoginSubmit_Click(object sender, RoutedEventArgs e)
        {
            var uname = TxtUsername.Text;
            var pword = TxtPassword.Password;

            if (!string.IsNullOrEmpty(uname))
            {
                if (!string.IsNullOrEmpty(pword))
                {
                    DbData data = new DbData();
                    var userId = data.CheckUserLogin(uname, pword);

                    if(userId == 0)
                    {
                        if (RegionInfo.CurrentRegion.NativeName == "France")
                        {
                            MessageBox.Show("La connexion a échoué, veuillez entrer des données valides", "Alerte", MessageBoxButton.OK);
                        }
                        else if (RegionInfo.CurrentRegion.EnglishName == "United States")
                        {
                            MessageBox.Show("Login failed, please enter valid data", "Alert", MessageBoxButton.OK);
                        }
                    }
                    else
                    {
                        loginSuccess = true;
                        ((MainWindow)Application.Current.MainWindow).getUserId(userId);
                        LogUserAttempt(userId.ToString());
                        this.Close();
                    }
                }
                else
                {
                    errorMessage();
                }
            }
            else
            {
                errorMessage();
            }            
        }

        private void LoginCancel_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void errorMessage()
        {
            MessageBox.Show("Username or Password is incorrect", "Alert", MessageBoxButton.OK);
        }

        private void LogUserAttempt(string userId)
        {
            using (StreamWriter sw = new StreamWriter("login.txt", true))
            {                
                sw.WriteLine($"UserId {userId} logged in at {DateTime.Now.ToString()}");
                sw.Close();
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (loginSuccess == false)
            {
                Application.Current.Shutdown();
            }
        }
        
    }
}
