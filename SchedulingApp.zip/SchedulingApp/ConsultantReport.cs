﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchedulingApp
{
    public class ConsultantReport
    {
        public string userName { get; set; }
        public string customerName { get; set; }
        public string start { get; set; }
        public string end { get; set; }

    }
}
